predict.SGL = function(x,newX,lam,y){
    cvobj = x
    
    X <- newX
    
    if(!is.null(x$X.transform)){
        X <- t(t(newX) - x$X.transform$X.means)
        X <- t(t(X) / x$X.transform$X.scale)
    }
    
    intercept <- 0
    
    if(!is.null(x$intercept)){
        intercept <- x$intercept[lam]
    }
    
    eta <- X %*% x$beta[,lam] + intercept
    
    
    if(x$type == "linear"){
        y.pred <- eta
    }

    nbeta=sum(x$beta[,lam]!=0)
    freedomDegree=n-nbeta-1
    n=length(y)
    RSS=sum((y.pred-y)^2)
    ymean=mean(y)
    TSS=sum((y-ymean)^2)
    ResidualStandardError=sqrt(RSS/freedomDegree)
    adjustedRSquare=1-(RSS/freedomDegree)/(TSS/n-1)
    FStatistic=((TSS-RSS)/nbeta)/(RSS/freedomDegree)
    Pvalue=2*(1-pf(FStatistic,nbeta,freedomDegree))
    y.pred=list(y.pred,ResidualStandardError,adjustedRSquare,FStatistic,Pvalue)
    return(y.pred)
}
